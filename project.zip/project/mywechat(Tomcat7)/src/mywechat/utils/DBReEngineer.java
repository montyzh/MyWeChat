package mywechat.utils;

import com.pr.utils.re_engineer.ReEngineerForVoUtil;

public class DBReEngineer {

	public static void main(String[] args) {
		new ReEngineerForVoUtil().create();
	}
}
