package mywechat.vo;

public class VO_Rely {
	   	private Integer id;
	    private Integer circleId;
	    private String content;
	    private String nick;
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public Integer getCircleId() {
			return circleId;
		}
		public void setCircleId(Integer circleId) {
			this.circleId = circleId;
		}
		public String getContent() {
			return content;
		}
		public void setContent(String content) {
			this.content = content;
		}
		public String getNick() {
			return nick;
		}
		public void setNick(String nick) {
			this.nick = nick;
		}
}
