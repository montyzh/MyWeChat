package mywechat.store;

import mywechat.store.auto._AddFriendTemp;

public class AddFriendTemp extends _AddFriendTemp {

}
