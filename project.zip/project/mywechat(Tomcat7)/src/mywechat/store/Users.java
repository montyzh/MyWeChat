package mywechat.store;

import mywechat.store.auto._Users;

public class Users extends _Users {

}
