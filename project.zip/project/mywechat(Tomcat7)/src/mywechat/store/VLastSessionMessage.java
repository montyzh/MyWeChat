package mywechat.store;

import mywechat.store.auto._VLastSessionMessage;

public class VLastSessionMessage extends _VLastSessionMessage {

}
