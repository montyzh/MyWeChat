package mywechat.store;

import mywechat.store.auto._Circle;

public class Circle extends _Circle {

}
