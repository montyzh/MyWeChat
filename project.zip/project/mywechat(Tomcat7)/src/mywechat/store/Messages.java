package mywechat.store;

import mywechat.store.auto._Messages;

public class Messages extends _Messages {

}
