package mywechat.store;

import mywechat.store.auto._Friends;

public class Friends extends _Friends {

}
