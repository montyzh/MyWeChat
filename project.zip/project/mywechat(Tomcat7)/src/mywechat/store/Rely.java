package mywechat.store;

import mywechat.store.auto._Rely;

public class Rely extends _Rely {

}
